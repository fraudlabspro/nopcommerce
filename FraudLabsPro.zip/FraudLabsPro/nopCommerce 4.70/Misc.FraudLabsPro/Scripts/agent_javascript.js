﻿(function(){
    function s() {
        var e = document.createElement('script');
        e.type = 'text/javascript';
        e.async = true;
        e.src = ('https:' === document.location.protocol ? 'https://' : 'http://') + 'cdn.fraudlabspro.com/s.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(e, s);
    }
        window.attachEvent ? window.attachEvent('onload', s) : window.addEventListener('load', s, false);
})();
