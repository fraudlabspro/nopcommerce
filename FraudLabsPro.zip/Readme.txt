1. 'Nop.Plugin.Misc.FraudLabsPro' directory contains source code.
2. 'Misc.FraudLabsPro' contains binaries. Just drop it into \Plugins directory on your server.